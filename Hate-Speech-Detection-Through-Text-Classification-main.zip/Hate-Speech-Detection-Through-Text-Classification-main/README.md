# Hate-Speech-Detection-Through-Text-Classification
## main.py
  Uses SVC model
## speech.py
  Uses Gemini APi
